using System;
namespace Application 
{
    public static class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello, is it me you're looking for?");
        }
    }
}

