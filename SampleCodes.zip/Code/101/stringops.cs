Dictionary<string, string> configuration = new Dictionary<string, string>();
configuration.Add("TYPE", "exec");
configuration.Add("COMMAND", "cmd.exe /c dir");       

