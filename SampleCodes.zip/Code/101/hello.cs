using System;
namespace Application 
{
    public static class Program
    {
        public static void Main()
        {
            // It's basically System.Console.WriteLine()
            // "using System" made it easier to use
            Console.WriteLine("Hello, is it me you’re looking for?");
        }
    }
}

